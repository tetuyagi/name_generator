import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:name_generator/views/random_words_widget.dart';



const String titleName = "My Name Generator";


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.bottom]);

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: titleName,
      home: RandomWordsWidget(titleName: titleName),
    );
  }
}


